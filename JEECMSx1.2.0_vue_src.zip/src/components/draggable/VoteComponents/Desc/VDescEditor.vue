<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'VDescEditor',
  extends: compoment
}
</script>
