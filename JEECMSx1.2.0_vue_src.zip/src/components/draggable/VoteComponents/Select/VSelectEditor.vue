<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'VSelectEditor',
  extends: compoment
}
</script>
