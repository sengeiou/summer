<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DAgePreview',
  extends: compoment
}
</script>
