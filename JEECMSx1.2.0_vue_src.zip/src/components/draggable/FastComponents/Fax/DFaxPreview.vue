<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DFaxPreview',
  extends: compoment
}
</script>
