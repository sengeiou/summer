<script>
import compoment from '@/components/draggable/CustomComponents/DateTime/DDateTimeEditor'
export default {
  name: 'DBirthdayEditor',
  extends: compoment
}
</script>
