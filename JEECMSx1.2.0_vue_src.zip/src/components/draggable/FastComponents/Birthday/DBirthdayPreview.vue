<script>
import compoment from '@/components/draggable/CustomComponents/DateTime/DDateTimePreview'
export default {
  name: 'DBirthdayPreview',
  extends: compoment
}
</script>
