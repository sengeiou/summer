<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DRadioPreview'
export default {
  name: 'DSexPreview',
  extends: compoment
}
</script>
