<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DEmailPreview',
  extends: compoment
}
</script>
