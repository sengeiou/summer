<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'DEmailEditor',
  extends: compoment
}
</script>
