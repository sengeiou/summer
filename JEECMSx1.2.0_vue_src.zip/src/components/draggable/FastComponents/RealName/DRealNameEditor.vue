<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'DRealNameEditor',
  extends: compoment
}
</script>
