<script>
import compoment from '@/components/draggable/VipDefaultComponents/DVipEditor'
export default {
  name: 'DPasswordEditor',
  extends: compoment
}
</script>
