<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DSimpleRadioPreview'
export default {
  name: 'DStatusPreview',
  extends: compoment
}
</script>
