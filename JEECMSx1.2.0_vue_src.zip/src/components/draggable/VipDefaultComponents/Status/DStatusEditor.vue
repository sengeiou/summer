<script>
import compoment from '@/components/draggable/VipDefaultComponents/DVipEditor'
export default {
  name: 'DStatusEditor',
  extends: compoment
}
</script>
