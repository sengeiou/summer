<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DRealnamePreview',
  extends: compoment
}
</script>
