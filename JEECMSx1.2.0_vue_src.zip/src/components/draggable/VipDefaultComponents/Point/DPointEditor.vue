<script>
import compoment from '@/components/draggable/VipDefaultComponents/DVipEditor'
export default {
  name: 'DPointEditor',
  extends: compoment
}
</script>
