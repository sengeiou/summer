<script>
import compoment from '@/components/draggable/CustomComponents/DateTime/DDateTimePreview'
export default {
  name: 'DOfflineTimePreview',
  extends: compoment
}
</script>
