<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'DSubTitleEditor',
  extends: compoment
}
</script>
