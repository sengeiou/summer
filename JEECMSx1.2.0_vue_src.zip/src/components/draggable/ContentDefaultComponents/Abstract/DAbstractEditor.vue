<script>
import compoment from '@/components/draggable/CustomComponents/Textarea/DTextareaEditor'
export default {
  name: 'DAbstractEditor',
  extends: compoment
}
</script>
