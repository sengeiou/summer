<script>
import compoment from '@/components/draggable/CustomComponents/ImageUpload/DImageUploadEditor'
export default {
  name: 'DSingleImageEditor',
  extends: compoment
}
</script>
