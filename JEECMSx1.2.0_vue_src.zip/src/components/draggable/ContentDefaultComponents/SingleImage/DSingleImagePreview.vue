<script>
import compoment from '@/components/draggable/CustomComponents/ImageUpload/DImageUploadPreview'
export default {
  name: 'DSingleImagePreview',
  extends: compoment
}
</script>
