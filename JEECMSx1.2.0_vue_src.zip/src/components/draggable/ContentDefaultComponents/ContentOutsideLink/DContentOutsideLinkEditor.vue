<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputEditor'
export default {
  name: 'DContentOutsideLinkEditor',
  extends: compoment
}
</script>
