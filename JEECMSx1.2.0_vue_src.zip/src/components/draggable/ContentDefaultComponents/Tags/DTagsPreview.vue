<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DTagsPreview',
  extends: compoment
}
</script>
