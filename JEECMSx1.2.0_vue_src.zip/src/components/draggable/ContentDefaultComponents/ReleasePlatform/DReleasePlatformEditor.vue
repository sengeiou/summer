<script>
import compoment from '@/components/draggable/CustomComponents/Checkbox/DCheckboxEditor'
export default {
  name: 'DReleasePlatformEditor',
  extends: compoment
}
</script>
