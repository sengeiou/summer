<script>
import compoment from '@/components/draggable/CustomComponents/Ueditor/DUeditorEditor'
export default {
  name: 'DContentEditor',
  extends: compoment
}
</script>
