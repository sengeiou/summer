<script>
import compoment from '@/components/draggable/CustomComponents/Select/DSelectEditor'
export default {
  name: 'DColumnPCTemplateEditor',
  extends: compoment
}
</script>
