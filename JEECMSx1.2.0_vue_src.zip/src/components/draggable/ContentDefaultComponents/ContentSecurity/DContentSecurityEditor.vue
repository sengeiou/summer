<script>
import compoment from '@/components/draggable/CustomComponents/Select/DSelectEditor'
export default {
  name: 'DContentSecurityEditor',
  extends: compoment
}
</script>
