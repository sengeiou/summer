<script>
import compoment from '@/components/draggable/CustomComponents/Select/DSelectEditor'
export default {
  name: 'DColumnEditor',
  extends: compoment
}
</script>
