<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DRadioEditor'
export default {
  name: 'DCommentSettingEditor',
  extends: compoment
}
</script>
