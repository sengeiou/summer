<script>
import compoment from '@/components/draggable/CustomComponents/DateTime/DDateTimePreview'
export default {
  name: 'DReleaseTimePreview',
  extends: compoment
}
</script>
