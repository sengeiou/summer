<script>
import compoment from '@/components/draggable/CustomComponents/Textarea/DTextareaPreview'
export default {
  name: 'DSeoDescPreview',
  extends: compoment
}
</script>
