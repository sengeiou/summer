<script>
import compoment from '@/components/draggable/CustomComponents/Textarea/DTextareaEditor'
export default {
  name: 'DSeoDescEditor',
  extends: compoment
}
</script>
