<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DSeoKeywordPreview',
  extends: compoment
}
</script>
