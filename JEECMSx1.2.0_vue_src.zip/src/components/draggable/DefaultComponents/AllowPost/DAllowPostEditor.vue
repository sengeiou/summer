<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DRadioEditor'
export default {
  name: 'DAllowPostEditor',
  extends: compoment
}
</script>
