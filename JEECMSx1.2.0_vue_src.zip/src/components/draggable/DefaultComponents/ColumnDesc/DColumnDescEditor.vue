<script>
import compoment from '@/components/draggable/CustomComponents/Textarea/DTextareaEditor'
export default {
  name: 'DColumnDescEditor',
  extends: compoment
}
</script>
