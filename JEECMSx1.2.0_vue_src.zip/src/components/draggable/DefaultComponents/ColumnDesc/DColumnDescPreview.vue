<script>
import compoment from '@/components/draggable/CustomComponents/Textarea/DTextareaPreview'
export default {
  name: 'DColumnDescPreview',
  extends: compoment
}
</script>
