<script>
import compoment from '@/components/draggable/CustomComponents/Input/DInputPreview'
export default {
  name: 'DSeoTitlePreview',
  extends: compoment
}
</script>
