<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DSimpleRadioPreview'
export default {
  name: 'DPaginationPreview',
  extends: compoment
}
</script>
