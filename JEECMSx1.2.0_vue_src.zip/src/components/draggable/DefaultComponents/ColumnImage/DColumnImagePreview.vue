<script>
import compoment from '@/components/draggable/CustomComponents/ImageUpload/DImageUploadPreview'
export default {
  name: 'DColumnImagePreview',
  extends: compoment
}
</script>
