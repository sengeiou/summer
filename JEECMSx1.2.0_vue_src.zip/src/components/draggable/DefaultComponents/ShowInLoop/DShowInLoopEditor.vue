<script>
import compoment from '@/components/draggable/CustomComponents/Radio/DRadioEditor'
export default {
  name: 'DShowInLoopEditor',
  extends: compoment
}
</script>
