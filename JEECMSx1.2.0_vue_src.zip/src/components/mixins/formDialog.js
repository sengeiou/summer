import FormDialog from '@/components/dialog/FormDialog'

export default {
  components: {
    FormDialog
  },
  data () {
    return {}
  }
}
