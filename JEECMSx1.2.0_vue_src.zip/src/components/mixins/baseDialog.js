import BaseDialog from '@/components/dialog/BaseDialog'

export default {
  components: {
    BaseDialog
  }
}
