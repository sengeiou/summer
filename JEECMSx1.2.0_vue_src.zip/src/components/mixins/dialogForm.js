import DialogForm from '@/components/form/DialogForm'

export default {
  components: {
    DialogForm
  },
  data () {
    return {}
  }
}
