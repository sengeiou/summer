import checkGroup from '@/components/checkGroup/checkGroup'

export default {
  components: {
    checkGroup
  },
  data () {
    return {

    }
  },
  methods: {
  }
}
