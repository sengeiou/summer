import checkList from '@/components/checkGroup/checkList'

export default {
  components: {
    checkList
  },
  data () {
    return {

    }
  },
  methods: {
  }
}
